// Pixel Survival - servidor de mundo (Cloudflare Worker + Durable Object)
// Un Durable Object = una sala/mundo persistente.
const MW = 320, TIERHP = [100, 300, 600, 1000], R = 44;
const dist = (a, b, c, d) => Math.hypot(a - c, b - d);
function center(k, f) {
  if (f) return [(k % MW) * 16 + 8, Math.floor(k / MW) * 16 + 8];
  const t = k & 1, i = k >> 1, x = i % (MW + 1), y = Math.floor(i / (MW + 1));
  return t === 0 ? [x * 16 + 8, y * 16] : [x * 16, y * 16 + 8];
}
async function pid(tok) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('ps:' + tok));
  return [...new Uint8Array(b)].slice(0, 4).map(x => x.toString(16).padStart(2, '0')).join('');
}

export default {
  async fetch(req, env) {
    const u = new URL(req.url);
    if (u.pathname !== '/ws') return new Response('Pixel Survival server OK');
    if (req.headers.get('Upgrade') !== 'websocket') return new Response('WebSocket requerido', { status: 426 });
    const room = (u.searchParams.get('room') || 'sala1').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 32) || 'sala1';
    return env.WORLD.get(env.WORLD.idFromName(room)).fetch(req);
  }
};

export class World {
  constructor(state) {
    this.st = state;
    this.edges = new Map(); this.furn = new Map(); this.inv = new Map();
    this.drops = new Map(); this.socks = new Map(); this.dirty = new Map(); this.timer = null;
    state.blockConcurrencyWhile(async () => {
      for (const [k, v] of await state.storage.list({ prefix: 'e:' })) this.edges.set(+k.slice(2), v);
      for (const [k, v] of await state.storage.list({ prefix: 'f:' })) this.furn.set(+k.slice(2), v);
      for (const [k, v] of await state.storage.list({ prefix: 'p:' })) this.inv.set(k.slice(2), v);
    });
  }
  mark(k, v) { this.dirty.set(k, v); if (!this.timer) this.timer = setTimeout(() => this.flush(), 5000); }
  async flush() {
    this.timer = null;
    const put = {}, del = [];
    for (const [k, v] of this.dirty) { if (v === undefined) del.push(k); else put[k] = v; }
    this.dirty.clear();
    const ks = Object.keys(put);
    for (let i = 0; i < ks.length; i += 100) { const o = {}; for (const k of ks.slice(i, i + 100)) o[k] = put[k]; await this.st.storage.put(o); }
    for (let i = 0; i < del.length; i += 100) await this.st.storage.delete(del.slice(i, i + 100));
  }
  bc(from, m) { const s = JSON.stringify(m); for (const [id, o] of this.socks) if (id !== from) { try { o.ws.send(s); } catch (e) {} } }
  to(id, m) { const o = this.socks.get(id); if (o) { try { o.ws.send(JSON.stringify(m)); } catch (e) {} } }

  async fetch(req) {
    const u = new URL(req.url), tok = (u.searchParams.get('tok') || '').slice(0, 64);
    if (tok.length < 8) return new Response('token', { status: 400 });
    const id = await pid(tok), name = (u.searchParams.get('n') || 'Jugador').slice(0, 12);
    const [cl, sv] = Object.values(new WebSocketPair());
    sv.accept();
    const old = this.socks.get(id);
    if (old) { this.socks.delete(id); try { old.ws.close(1000, 'dup'); } catch (e) {} }
    const me = { ws: sv, x: 0, y: 0, dead: 0, n: name, tD: 0, tS: 0, tB: 0 };
    this.socks.set(id, me);
    const now = Date.now();
    for (const [k, d] of this.drops) if (now - d.at > 6e5) this.drops.delete(k);
    sv.send(JSON.stringify({
      t: 'welcome', id, e: [...this.edges], f: [...this.furn],
      d: [...this.drops.values()].map(d => d.d), inv: this.inv.get(id) || null
    }));
    sv.addEventListener('message', ev => { try { this.onMsg(id, me, JSON.parse(ev.data)); } catch (e) {} });
    const bye = () => { if (this.socks.get(id) === me) { this.socks.delete(id); this.bc(id, { t: 'bye', i: id }); this.flush(); } };
    sv.addEventListener('close', bye); sv.addEventListener('error', bye);
    return new Response(null, { status: 101, webSocket: cl });
  }

  onMsg(id, me, m) {
    m.i = id; const now = Date.now();
    const S = f => f ? this.furn : this.edges, P = f => f ? 'f:' : 'e:';
    switch (m.t) {
      case 'pos':
        me.x = +m.x || 0; me.y = +m.y || 0; me.dead = m.d; me.n = String(m.n || me.n).slice(0, 12); m.n = me.n;
        this.bc(id, m); break;
      case 'put': {
        const out = { t: 'put', i: id, e: [], f: [] };
        for (const [k, p] of (m.e || []).slice(0, 50)) {
          const ex = this.edges.get(k); if (!(k >= 0) || !p || (ex && ex.o && ex.o !== id)) continue;
          p.o = id; p.hp = Math.min(+p.hp || 0, TIERHP[3]); this.edges.set(k, p); this.mark('e:' + k, p); out.e.push([k, p]);
        }
        for (const [k, p] of (m.f || []).slice(0, 50)) {
          const ex = this.furn.get(k); if (!(k >= 0) || !p || (ex && ex.o && ex.o !== id)) continue;
          p.o = id; p.r = 1; this.furn.set(k, p); this.mark('f:' + k, p); out.f.push([k, p]);
        }
        this.bc(id, out); break;
      }
      case 'del': {
        const p = S(m.f).get(m.k);
        if (p && p.o === id) { S(m.f).delete(m.k); this.mark(P(m.f) + m.k, undefined); this.bc(id, m); }
        break;
      }
      case 'door': {
        const p = this.edges.get(m.k);
        if (p && p.o === id && p.k === 'door') { p.open = !!m.open; this.mark('e:' + m.k, p); this.bc(id, m); }
        break;
      }
      case 'upg': {
        const p = this.edges.get(m.k);
        if (p && p.o === id && m.tier > p.tier && m.tier <= 3) {
          p.tier = m.tier; p.mx = p.hp = TIERHP[m.tier] * (p.k === 'door' ? .6 : 1);
          this.mark('e:' + m.k, p); this.bc(id, m);
        }
        break;
      }
      case 'cset': {
        const p = this.furn.get(m.k);
        if (p && p.slots && Array.isArray(m.s) && m.s.length === p.slots.length) { p.slots = m.s; this.mark('f:' + m.k, p); this.bc(id, m); }
        break;
      }
      case 'sd': { // daño a estructura (validado)
        if (now - me.tS < 200) break; me.tS = now;
        const n = Math.min(+m.n || 0, 12), mp = S(m.f), p = mp.get(m.k);
        if (!p || p.o === id) break;
        const c = center(m.k, m.f); if (dist(me.x, me.y, c[0], c[1]) > 70) break;
        p.hp -= n;
        if (p.hp <= 0) { mp.delete(m.k); this.mark(P(m.f) + m.k, undefined); this.bc(null, { t: 'del', i: 'srv', k: m.k, f: m.f ? 1 : 0 }); }
        else { this.mark(P(m.f) + m.k, p); this.bc(id, { t: 'sd', i: id, k: m.k, f: m.f ? 1 : 0, n }); }
        break;
      }
      case 'bomb': {
        const x = +m.x, y = +m.y;
        if (now - me.tB < 1000 || dist(me.x, me.y, x, y) > 50) break; me.tB = now;
        this.bc(id, { t: 'bomb', i: id, x, y });
        setTimeout(() => this.explode(id, x, y), 5000); break;
      }
      case 'dmg': { // PvP validado por el servidor
        const t = this.socks.get(m.to);
        if (!t || t.dead || me.dead || now - me.tD < 70) break; me.tD = now;
        if (dist(me.x, me.y, t.x, t.y) > 300) break;
        this.to(m.to, { t: 'dmg', i: id, to: m.to, n: Math.min(+m.n || 0, 100) }); break;
      }
      case 'shoot': case 'dead': this.bc(id, m); break;
      case 'drops':
        for (const d of (m.d || []).slice(0, 40)) this.drops.set(d.u, { d: { id: d.id, n: d.n, x: d.x, y: d.y, u: d.u }, at: now });
        this.bc(id, m); break;
      case 'pick': {
        const e = this.drops.get(m.u);
        if (e) { if (m.n <= 0) this.drops.delete(m.u); else e.d.n = m.n; }
        this.bc(id, m); break;
      }
      case 'inv':
        if (Array.isArray(m.inv) && m.inv.length <= 30) { this.inv.set(id, m.inv); this.mark('p:' + id, m.inv); }
        for (const [k, p] of (m.f || []).slice(0, 100)) {
          const ex = this.furn.get(k);
          if (ex && ex.o === id) { Object.assign(ex, { hp: p.hp, auth: p.auth, inp: p.inp, out: p.out, acc: p.acc, fuel: p.fuel }); this.mark('f:' + k, ex); }
        }
        break;
    }
  }

  explode(by, x, y) {
    for (const f of [false, true]) {
      const mp = f ? this.furn : this.edges;
      for (const [k, p] of mp) {
        if (p.o === by) continue;
        const c = center(k, f); if (dist(c[0], c[1], x, y) > R) continue;
        p.hp -= 350;
        this.bc(null, { t: 'sd', i: 'srv', k, f: f ? 1 : 0, n: 350 });
        if (p.hp <= 0) { mp.delete(k); this.mark((f ? 'f:' : 'e:') + k, undefined); this.bc(null, { t: 'del', i: 'srv', k, f: f ? 1 : 0 }); }
        else this.mark((f ? 'f:' : 'e:') + k, p);
      }
    }
  }
}
